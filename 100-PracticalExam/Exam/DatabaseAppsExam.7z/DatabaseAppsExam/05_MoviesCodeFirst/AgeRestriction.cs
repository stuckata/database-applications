﻿namespace _05_CodeFirstMovies
{
    public enum AgeRestriction
    {
        Child,
        Teen,
        Adult
    }
}
